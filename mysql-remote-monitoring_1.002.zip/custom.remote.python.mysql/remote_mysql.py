"""
OneAgent MySQL plugin
=====================

Gathers stats from a given MySQL server instance. The stats are selected values from 2 queries:

 * show global status (http://dev.mysql.com/doc/refman/5.7/en/show-variables.html)
 * show global variables (http://dev.mysql.com/doc/refman/5.7/en/show-status.html)

Running the plugin requires specifying user credentials and server port in the configuration.

This is a remote plugin - one custom device will be created for each endpoint.
"""

from ruxit.api.base_plugin import RemoteBasePlugin
from ruxit.api.exceptions import AuthException, ConfigException
import itertools
import logging
import socket

try:
    import pymysql.cursors
except OSError as mysql_load_ex:
    raise ConfigException("Unable to load mysql connector library") from mysql_load_ex

logger = logging.getLogger(__name__)


class RemoteMySqlPlugin(RemoteBasePlugin):
    """
    MySQL plugin class. This plugin is stateful - initialize and close methods are defined
    in order to maintain one server connection for the lifetime of the plugin.

    Class fields mirror measurements declared in the plugin.json
    and declare some few parameters i.e: connection timeout, error codes
    """
    _DEFAULT_TIMEOUT = 5

    # see http://dev.mysql.com/doc/refman/5.7/en/error-messages-server.html
    _MYSQL_ACCESS_DENIED_ERRORS = [1044, 1045, 1142, 1143, 1227, 1370, 1698, 1873, 3118]
    # see https://dev.mysql.com/doc/refman/5.7/en/error-messages-client.html
    _MYSQL_CONNECTION_ERRORS = [2003]

    _STATUS_RELATIVE_VALUES = {
        'threads_connected',
        'connection_errors_max_connections',
        'queries',
        'slow_queries',
        'questions',
        'created_tmp_tables',
        'created_tmp_disk_tables',
        'table_locks_waited',
        'innodb_buffer_pool_pages_total',
        'innodb_buffer_pool_pages_dirty',
        'innodb_buffer_pool_pages_free',
        'innodb_buffer_pool_pages_data',
        'threads_created',
        'threads_running',
        'table_locks_immediate'
    }

    _STATUS_PER_SECOND_VALUES = {
        'com_delete',
        'com_delete_multi',
        'com_insert',
        'com_insert_select',
        'com_update',
        'com_update_multi',
        'com_select',
        'com_replace_select',
        'qcache_queries_in_cache',
        'innodb_data_reads',
        'innodb_data_writes',
        'qcache_hits',
        'qcache_not_cached'
    }

    _STATUS_ABSOLUTE_VALUES = {
        'innodb_buffer_pool_pages_total',
        'innodb_buffer_pool_pages_dirty',
        'innodb_buffer_pool_pages_free',
        'innodb_buffer_pool_pages_data',
        'threads_connected',
        'threads_created',
        'threads_running',
        'qcache_free_memory',
        'qcache_queries_in_cache'
    }

    # quotient = numerator/denominator
    _STATUS_RATE_VALUES = {
        'slow_queries_rate': {'numerator': 'slow_queries', 'denominator': 'queries'}
    }

    _VARS_ABSOLUTE_VALUES = {
        'innodb_buffer_pool_size'
    }

    _STATUS_VARIABLES = _STATUS_RELATIVE_VALUES.union(
        _STATUS_ABSOLUTE_VALUES).union(_STATUS_PER_SECOND_VALUES)
    _ABSOLUTE_VALUES = _STATUS_ABSOLUTE_VALUES.union(_VARS_ABSOLUTE_VALUES)

    def initialize(self, **kwargs):
        """
        Initializes the mysql plugin.

        This parses the configuration of the plugin and initiates a connection object so that
        every query does not need to establish a new connection.

        The connection is established over tcp by specifying 127.0.0.1 as connection address. Using
        localhost would cause the connection to be made via unix sockets which would require additional
        discovery of the socket. Note that this is the limitation of the C connector library and
        other package can behave differently.

        Raises:
            ruxit.api.exceptions.AuthException:  mysql server returned error indicating auth issues
            ruxit.api.exceptions.ConfigException: unable to connect for other reasons
        """
        # build list of locally calculated relative metrics
        self._rate_metrics = set()
        for m in self._STATUS_RATE_VALUES:
            mdef = self._STATUS_RATE_VALUES[m]
            self._rate_metrics.add(mdef['denominator'])
            self._rate_metrics.add(mdef['numerator'])
        self._rate_old_results = {}
        self._rate_results = {}

    def getConnectionAndCursor(self, **kwargs):
        config = kwargs["config"]
        if not config['connection_port']:
            raise ConfigException("Port field is empty")
        self.port = int(config["connection_port"])
        if not config['connection_host']:
            raise ConfigException("Port field is empty")
        self.host = config['connection_host']

        connection_config = {
            'user': config["connection_user"].encode('ascii'),
            'passwd': config["connection_password"].encode('ascii'), 'port': self.port,
            'host': self.host.encode("ascii"), 'connect_timeout': self._DEFAULT_TIMEOUT
        }
        try:
            self.connection = pymysql.connect(**connection_config)
            self.cursor = self.connection.cursor()
        except pymysql.err.OperationalError as ex:
            if ex.args[0] in self._MYSQL_ACCESS_DENIED_ERRORS:
                raise AuthException from ex
            elif ex.args[0] in self._MYSQL_CONNECTION_ERRORS:
                raise ConfigException("Unable to connect to MySQL server") from ex
            elif len(ex.args) > 1:
                raise ConfigException(ex.args[1]) from ex
            raise

    def buildToplogy(self):
        self.cursor.execute(b'SHOW VARIABLES LIKE "version_comment";')
        databaseTypeResults = self.cursor.fetchall()
        databaseType = databaseTypeResults[0][1]
        databaseType = databaseType.lower()
        if "mariadb" in databaseType:
            cdGroup = self.topology_builder.create_group("MariaDB", "MariaDB")
        else:
            cdGroup = self.topology_builder.create_group("MySQL", "MySQL")
        deviceName = str(self.host) + ":" + str(self.port)
        self.device = cdGroup.create_device(deviceName, deviceName)
        try:
            sqlIPAddress = socket.gethostbyname(self.host)
        except socket.gaierror as e:
            logger.exception("Could not get IP address of MySQL Server: " + e)
        if str(sqlIPAddress) == self.host:
            self.device.add_endpoint(ip=sqlIPAddress, port=self.port)
        else:
            dnsNamesList = []
            dnsNamesList.append(self.host)
            self.device.add_endpoint(ip=sqlIPAddress, port=self.port, dnsNames=dnsNamesList)

    # this below assumes that rate metrics are dimension-less
    def _store_relative_metric(self, metric):
        for k in metric:
            if k in self._rate_metrics:
                self._rate_results[k] = metric.get(k)

    def _flush_rate_metrics(self):
        # calculate deltas and store them for next step
        tmp_rate_metrics = {}
        for metric, result in self._rate_results.items():
            old_result = self._rate_old_results.get(metric, None)
            if old_result is not None:
                value_delta = int(result) - int(old_result)
                if value_delta < 0:
                    continue
                tmp_rate_metrics[metric] = value_delta

        # walk all rate metrics defitions and calculate values based on tmp_rate_metrics
        for mkey, mdef in self._STATUS_RATE_VALUES.items():
            mdef_numerator = tmp_rate_metrics.get(mdef['numerator'], None)
            mdef_denominator = tmp_rate_metrics.get(mdef['denominator'], None)
            if mdef_numerator is not None and mdef_denominator is not None:
                if mdef_numerator >= 0 and mdef_denominator > 0:
                    self.device.absolute(key=mkey, value=100.0 * mdef_numerator/mdef_denominator)

        self._rate_old_results = self._rate_results
        self._rate_results = {}

    def query(self, **kwargs):
        """
        Gathers the mysql data from global status and global variables queries.

        The measurements use a ruxit.api.selectors.ListenPortSelector to associate data with correct
        entity id (the mysql server process group) in case of multiple MySQL instances running
        on a host.

        Raises:
            ruxit.api.exceptions.AuthException:  mysql server returned error indicating auth issues
            ruxit.api.exceptions.ConfigException: unable to connect for other reasons
        """
        self.getConnectionAndCursor(**kwargs)
        self.buildToplogy()
        try:
            variables_query_fragment = ', '.join('\'%s\'' % it for it in self._STATUS_VARIABLES)
            status_query = 'show global status where variable_name in (%s)' % variables_query_fragment
            status_query = status_query.encode('ascii')
            self.cursor.execute(status_query)
            global_status_rows = self.cursor.fetchall()

            self.cursor.execute(
                b'show global variables where variable_name in (\'innodb_buffer_pool_size\')'
            )
            global_variables_rows = self.cursor.fetchall()

            self.cursor.execute(b'SHOW VARIABLES LIKE "version";')
            database_version = self.cursor.fetchall()
        except pymysql.err.OperationalError as ex:
            if ex.args[0] in self._MYSQL_ACCESS_DENIED_ERRORS:
                raise AuthException from ex
            elif ex.args[0] in self._MYSQL_CONNECTION_ERRORS:
                raise ConfigException("Unable to connect to MySQL server") from ex
            elif len(ex.args) > 1:
                raise ConfigException(ex.args[1]) from ex
            raise

        self.device.report_property(key="Database Version", value=database_version[0][1])

        results = []
        for row in itertools.chain(global_status_rows, global_variables_rows):
            tmpKey = row[0].lower()
            tmpDict = {tmpKey: row[1]}
            results.append(tmpDict)

        for r in results:
            for k in r:
                if k in self._ABSOLUTE_VALUES:
                    self.device.absolute(key=k, value=r.get(k))
                elif k in self._STATUS_PER_SECOND_VALUES:
                    self.device.per_second(key=k, value=r.get(k))
                else:
                    self.device.relative(key=k, value=r.get(k))
                    self._store_relative_metric(r)

        self._flush_rate_metrics()
        try:
            self.cursor.close()
            if self.connection.open:
                self.connection.close()
        except pymysql.err.OperationalError as ex:
            logger.exception("In query:" + ex)

    def close(self, **kwargs):
        try:
            if self.connection.open:
                self.connection.close()
        except pymysql.err.OperationalError as ex:
            logger.exception("In close:" + ex)
